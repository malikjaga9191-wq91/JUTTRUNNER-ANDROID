# JUTTRUNNER development roadmap

## Included in this prototype
- Procedural 3D corridor, glowing runes/crystals, player placeholder
- Three-lane movement, jump, slide, swipe and button controls
- Endless segment recycling, obstacle/crystal spawning
- Run distance, crystal balance, best score persistence
- Menu, pause, restart, game-over, basic shop purchase flow

## Stage 2 — dungeon polish
- Add multiple segment scenes and weighted procedural theme selection
- Add enemy scenes with telegraphed movement and collision states
- Add animation state machine and improved player rig
- Add particles and original/licensed sound effects
- Add portals, bridge segments, floor traps, overhead slide obstacles

## Stage 3 — roster and economy
- Implement character resources with stats, ability data, prices, unlock state
- Add real character preview models and equipment persistence
- Add skin, trail, dungeon theme and power-up inventory categories
- Add purchase confirmation dialogue and clear insufficient-funds feedback

## Stage 4 — progression and settings
- Add daily/weekly mission tracking, achievements and rewards
- Add ability cooldowns and complete visual/audio feedback
- Add sound/music toggles, graphics quality, swipe/button mode
- Add localization and safe-area/responsive UI refinements

## Stage 5 — verification and release
- Test on low-end Android devices and multiple aspect ratios
- Profile physics, materials, draw calls and object counts
- Validate pause/resume and save migration
- Configure Android export preset, package ID, icon, signing and versioning
- Export and install debug APK, then test on a real device
