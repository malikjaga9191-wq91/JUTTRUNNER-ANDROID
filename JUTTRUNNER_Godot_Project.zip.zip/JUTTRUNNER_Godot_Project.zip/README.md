# JUTTRUNNER — Godot 4 3D Android Runner

This is a **playable Stage 1 prototype** built from procedural meshes and GDScript. It includes:
- 3 lanes with keyboard, mouse-swipe, touchscreen-swipe, and on-screen controls
- Jump and slide actions
- Endless modular dungeon corridor
- Random obstacles and Mana Crystal pickups
- Increasing speed, distance counter, persistent crystal balance and best distance
- Pause, restart, game-over, Hunters placeholder screen, and a crystal shop
- No paid assets, plugins, or external dependencies

## Important status notes
This ZIP is a source project, **not an APK**. It has not been run in Godot by this packaging step, so please validate it in your chosen Godot 4.x environment. The hunter models, animations, sound, missions, and final shop/equipment screens are still prototype placeholders; this is not yet the complete polished game shown in the reference image. The game uses original procedural placeholder geometry rather than copied characters or assets.

## Open and test on a computer
1. Install Godot 4.x (Godot 4.3 or newer recommended).
2. Extract this ZIP.
3. In Godot Project Manager choose **Import**, select this folder's `project.godot`.
4. Press **F6** or **F5** to run.
5. Controls:
   - Left/Right arrow or A/D: change lanes
   - Space/Up: jump
   - Down/S: slide
   - Touch swipe left/right/up/down on Android
   - On-screen buttons also work

## Android export
Recommended route: use desktop Godot editor with Android export templates and Android SDK/JDK configured. Termux can store/edit the source, but a normal Android APK export is generally more reliable from Godot's supported editor/export environment or CI.

1. Install Godot 4.x desktop and matching export templates (Editor > Manage Export Templates).
2. Install a supported JDK (follow the Godot version's official Android export requirements; JDK 17 is commonly used for recent Godot 4 releases).
3. Install Android SDK command-line tools/platform-tools and the SDK platform/build-tools versions required by your Godot release.
4. In Godot: **Editor > Editor Settings > Export > Android**, set Java SDK Path and Android SDK Path.
5. Open **Project > Export**, add an **Android** preset, enable arm64-v8a (and any other desired architecture), and configure the package name.
6. Choose **Export Project**, select an output path such as `JUTTRUNNER-debug.apk`, and export.
7. Copy the APK to the Android phone and install it. You may need to allow installation from that file manager/source.

## Validation commands
Run these in a shell where Godot is installed:
```sh
godot --version
godot --headless --path . --editor --quit
godot --headless --path . --quit-after 120
```
The exact command-line Android export flags and SDK versions can differ by Godot release. First create and verify an Android export preset in the editor, then use the preset name shown in the export configuration. Do not assume an APK exists until export succeeds.

## Termux notes
Termux is useful for extracting and editing the project:
```sh
pkg update
pkg install unzip git
mkdir -p ~/JUTTRUNNER
cd ~/JUTTRUNNER
unzip /path/to/JUTTRUNNER_Godot_Project.zip
```
If your Godot build is installed in Termux, try the validation commands above. Some Termux builds differ from desktop Godot and may not include the Android export templates or editor UI. Building an APK directly on the phone is not guaranteed.

## Save data
Progress is stored in Godot's `user://juttrunner_save.json`, which persists locally per app installation.

## Project layout
- `project.godot` — project settings and input actions
- `scenes/main.tscn` — main scene
- `scripts/main.gd` — procedural 3D world, runner movement, spawners, UI, save/shop logic
- `docs/ROADMAP.md` — staged next steps

## Roadmap
See `docs/ROADMAP.md` for Stage 2–5 development tasks.


## GitHub Actions cloud APK build (experimental starter workflow)
This project now includes `.github/workflows/android-apk.yml` and `export_presets.cfg`.
1. Upload the **contents** of this project folder to a GitHub repository (the `project.godot` file must be in the repository root).
2. Open the repository's **Actions** tab.
3. Select **Build JUTTRUNNER Android APK** from the workflow list.
4. Tap **Run workflow**. A push to the `main` branch also triggers the workflow.
5. Open the completed run, scroll to **Artifacts**, and download `JUTTRUNNER-debug-apk`.
6. Extract the downloaded artifact ZIP and install `JUTTRUNNER-debug.apk` on your Android phone.

Important: this is a starter workflow and has **not been executed or verified in GitHub Actions** in this environment. If it fails, open the failed run and share the first red error lines so the workflow can be corrected. It builds a debug APK for device testing, not a signed Play Store release. GitHub-hosted Actions usage and limits depend on account and repository settings.
