extends Node3D
## JUTTRUNNER playable prototype. All visuals are procedural placeholders.

const SAVE_PATH := "user://juttrunner_save.json"
const LANES := [-2.2, 0.0, 2.2]
const SEGMENT_LENGTH := 22.0
const SEGMENT_COUNT := 7
const CRYSTAL_VALUE := 1

var player: CharacterBody3D
var camera: Camera3D
var world_root: Node3D
var obstacle_root: Node3D
var crystal_root: Node3D
var segments: Array[Node3D] = []
var lane := 1
var target_x := 0.0
var vertical_velocity := 0.0
var gravity := 22.0
var jump_strength := 9.5
var run_speed := 12.0
var base_speed := 12.0
var distance_m := 0.0
var crystals_run := 0
var crystals_total := 0
var best_distance := 0.0
var running := false
var game_started := false
var is_sliding := false
var slide_timer := 0.0
var spawn_distance := 30.0
var next_obstacle_z := 24.0
var next_crystal_z := 8.0
var elapsed := 0.0
var shield_hits := 0
var power_timers := {"magnet": 0.0, "shield": 0.0, "double": 0.0, "boost": 0.0}
var touch_start := Vector2.ZERO
var touch_active := false
var ui_layer: CanvasLayer
var hud: Control
var menu_panel: PanelContainer
var gameover_panel: PanelContainer
var pause_panel: PanelContainer
var shop_panel: PanelContainer
var hunters_panel: PanelContainer
var status_label: Label
var distance_label: Label
var crystal_label: Label
var message_label: Label
var best_label: Label
var rng := RandomNumberGenerator.new()
var saved_data: Dictionary = {}

func _ready() -> void:
    rng.randomize()
    _load_save()
    _build_world()
    _build_ui()
    _show_menu()

func _process(delta: float) -> void:
    if not running:
        return
    elapsed += delta
    run_speed = base_speed + minf(distance_m * 0.006, 9.0)
    distance_m += run_speed * delta
    player.velocity.z = 0.0
    player.velocity.x = (target_x - player.global_position.x) * 13.0
    if player.is_on_floor():
        if vertical_velocity < 0.0:
            vertical_velocity = 0.0
    vertical_velocity -= gravity * delta
    player.velocity.y = vertical_velocity
    player.move_and_slide()
    player.global_position.x = lerpf(player.global_position.x, target_x, minf(delta * 8.0, 1.0))
    if player.global_position.y < -5.0:
        _end_run()
    if is_sliding:
        slide_timer -= delta
        if slide_timer <= 0.0:
            is_sliding = false
            player.scale.y = 1.0
    camera.global_position = camera.global_position.lerp(player.global_position + Vector3(0.0, 5.4, 9.0), minf(delta * 4.0, 1.0))
    camera.look_at(player.global_position + Vector3(0.0, 1.0, -7.0), Vector3.UP)
    _move_segments(delta)
    _move_world_items(delta)
    _spawn_world_items()
    _check_pickups()
    _check_collisions()
    for key in power_timers.keys():
        power_timers[key] = maxf(0.0, float(power_timers[key]) - delta)
    _update_hud()

func _unhandled_input(event: InputEvent) -> void:
    if not running:
        return
    if event.is_action_pressed("ui_left"):
        _change_lane(-1)
    elif event.is_action_pressed("ui_right"):
        _change_lane(1)
    elif event.is_action_pressed("jump"):
        _jump()
    elif event.is_action_pressed("slide"):
        _slide()
    elif event is InputEventScreenTouch:
        if event.pressed:
            touch_start = event.position
            touch_active = true
        elif touch_active:
            var delta := event.position - touch_start
            touch_active = false
            if delta.length() > 35.0:
                if absf(delta.x) > absf(delta.y):
                    _change_lane(1 if delta.x > 0 else -1)
                elif delta.y < 0:
                    _jump()
                else:
                    _slide()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        touch_start = event.position
        touch_active = true
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed and touch_active:
        var delta := event.position - touch_start
        touch_active = false
        if delta.length() > 35.0:
            if absf(delta.x) > absf(delta.y):
                _change_lane(1 if delta.x > 0 else -1)
            elif delta.y < 0:
                _jump()
            else:
                _slide()

func _build_world() -> void:
    world_root = Node3D.new()
    world_root.name = "World"
    add_child(world_root)
    obstacle_root = Node3D.new()
    obstacle_root.name = "Obstacles"
    world_root.add_child(obstacle_root)
    crystal_root = Node3D.new()
    crystal_root.name = "Crystals"
    world_root.add_child(crystal_root)

    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.015, 0.025, 0.12)
    sky_mat.sky_horizon_color = Color(0.08, 0.04, 0.19)
    sky_mat.ground_bottom_color = Color(0.01, 0.01, 0.035)
    sky_mat.ground_horizon_color = Color(0.03, 0.025, 0.08)
    environment.sky.sky_material = sky_mat
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.18, 0.2, 0.42)
    environment.ambient_light_energy = 0.8
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = environment
    add_child(env)

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-48, -25, 0)
    light.light_color = Color(0.42, 0.55, 1.0)
    light.light_energy = 1.4
    add_child(light)

    for i in range(SEGMENT_COUNT):
        var seg := _make_segment()
        seg.position.z = -float(i) * SEGMENT_LENGTH
        world_root.add_child(seg)
        segments.append(seg)

    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0, 0.9, 2.5)
    player.floor_snap_length = 0.25
    player.motion_mode = CharacterBody3D.MOTION_MODE_GROUNDED
    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.55
    body.mesh = capsule
    body.position.y = 0.0
    body.material_override = _mat(Color(0.055, 0.09, 0.22), 0.25, Color(0.0, 0.25, 1.0))
    player.add_child(body)
    var head := MeshInstance3D.new()
    var headmesh := SphereMesh.new()
    headmesh.radius = 0.28
    headmesh.height = 0.56
    head.mesh = headmesh
    head.position = Vector3(0, 0.92, 0)
    head.material_override = _mat(Color(0.08, 0.12, 0.23), 0.1, Color(0.0, 0.45, 1.0))
    player.add_child(head)
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.4
    shape.height = 1.7
    collision.shape = shape
    player.add_child(collision)
    world_root.add_child(player)

    camera = Camera3D.new()
    camera.name = "RunnerCamera"
    camera.position = Vector3(0, 5.8, 11.5)
    camera.current = true
    camera.fov = 72
    add_child(camera)
    camera.look_at(Vector3(0, 1, -5), Vector3.UP)

func _make_segment() -> Node3D:
    var seg := Node3D.new()
    var floor := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(8.3, 0.5, SEGMENT_LENGTH)
    floor.mesh = box
    floor.position = Vector3(0, -0.35, -SEGMENT_LENGTH / 2.0)
    floor.material_override = _mat(Color(0.075, 0.08, 0.16), 0.2, Color(0.0, 0.04, 0.18))
    seg.add_child(floor)
    var floor_col := StaticBody3D.new()
    floor_col.position = floor.position
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = box.size
    cs.shape = bs
    floor_col.add_child(cs)
    seg.add_child(floor_col)
    for x in [-4.35, 4.35]:
        var wall := MeshInstance3D.new()
        var wm := BoxMesh.new()
        wm.size = Vector3(0.55, 4.0, SEGMENT_LENGTH)
        wall.mesh = wm
        wall.position = Vector3(x, 1.55, -SEGMENT_LENGTH / 2.0)
        wall.material_override = _mat(Color(0.055, 0.065, 0.13), 0.2, Color(0.05, 0.08, 0.35))
        seg.add_child(wall)
        for z in [-4.0, -12.0, -20.0]:
            var crystal := _crystal_mesh()
            crystal.position = Vector3(x * 0.82, 1.4, z)
            crystal.scale = Vector3(0.45, 1.1, 0.45)
            seg.add_child(crystal)
    for x in [-1.1, 1.1]:
        var stripe := MeshInstance3D.new()
        var sm := BoxMesh.new()
        sm.size = Vector3(0.045, 0.015, SEGMENT_LENGTH)
        stripe.mesh = sm
        stripe.position = Vector3(x, -0.08, -SEGMENT_LENGTH / 2.0)
        stripe.material_override = _mat(Color(0.0, 0.35, 0.8), 0.0, Color(0.0, 0.35, 1.0))
        seg.add_child(stripe)
    # Gothic pillars make the corridor feel like a dungeon.
    for side in [-1.0, 1.0]:
        for z in [-5.0, -15.0]:
            var pillar := MeshInstance3D.new()
            var pm := BoxMesh.new()
            pm.size = Vector3(0.65, 4.5, 0.7)
            pillar.mesh = pm
            pillar.position = Vector3(side * 3.65, 1.9, z)
            pillar.material_override = _mat(Color(0.11, 0.09, 0.2), 0.2, Color(0.08, 0.04, 0.25))
            seg.add_child(pillar)
            var rune := MeshInstance3D.new()
            var rm := BoxMesh.new()
            rm.size = Vector3(0.72, 0.06, 0.09)
            rune.mesh = rm
            rune.position = pillar.position + Vector3(0, 0.5, -0.38)
            rune.material_override = _mat(Color(0.05, 0.35, 1.0), 0.1, Color(0.0, 0.4, 1.0))
            seg.add_child(rune)
    return seg

func _mat(color: Color, metallic: float = 0.0, emission: Color = Color.BLACK) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = 0.38
    if emission != Color.BLACK:
        m.emission_enabled = true
        m.emission = emission
        m.emission_energy_multiplier = 1.8
    return m

func _crystal_mesh() -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := PrismMesh.new()
    mesh.size = Vector3(0.5, 0.85, 0.5)
    node.mesh = mesh
    node.material_override = _mat(Color(0.05, 0.7, 1.0), 0.25, Color(0.0, 0.55, 1.0))
    return node

func _move_segments(delta: float) -> void:
    for seg in segments:
        seg.position.z += run_speed * delta
        if seg.position.z > SEGMENT_LENGTH:
            var min_z := 0.0
            for other in segments:
                min_z = minf(min_z, other.position.z)
            seg.position.z = min_z - SEGMENT_LENGTH

func _move_world_items(delta: float) -> void:
    for n in obstacle_root.get_children():
        n.position.z += run_speed * delta
    for n in crystal_root.get_children():
        n.position.z += run_speed * delta

func _spawn_world_items() -> void:
    if distance_m >= next_obstacle_z:
        next_obstacle_z += rng.randf_range(17.0, 25.0)
        var lane_index := rng.randi_range(0, 2)
        var obstacle := StaticBody3D.new()
        obstacle.name = "Obstacle"
        obstacle.set_meta("kind", "obstacle")
        obstacle.position = Vector3(LANES[lane_index], 0.72, player.global_position.z - rng.randf_range(48.0, 68.0))
        var mesh := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(1.25, 1.4, 0.9)
        mesh.mesh = box
        mesh.material_override = _mat(Color(0.23, 0.035, 0.22), 0.2, Color(0.8, 0.0, 0.35))
        obstacle.add_child(mesh)
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = box.size
        cs.shape = bs
        obstacle.add_child(cs)
        obstacle_root.add_child(obstacle)
    if distance_m >= next_crystal_z:
        next_crystal_z += rng.randf_range(7.0, 12.0)
        var lane_index := rng.randi_range(0, 2)
        var crystal := Area3D.new()
        crystal.name = "ManaCrystal"
        crystal.set_meta("kind", "crystal")
        crystal.position = Vector3(LANES[lane_index], 1.1, player.global_position.z - rng.randf_range(35.0, 65.0))
        var mesh := _crystal_mesh()
        mesh.scale = Vector3(0.85, 0.95, 0.85)
        crystal.add_child(mesh)
        var cs := CollisionShape3D.new()
        var sphere := SphereShape3D.new()
        sphere.radius = 0.85
        cs.shape = sphere
        crystal.add_child(cs)
        crystal_root.add_child(crystal)
    # Remove objects that have passed behind the player.
    for n in obstacle_root.get_children():
        if n.global_position.z > player.global_position.z + 12.0:
            n.queue_free()
    for n in crystal_root.get_children():
        if n.global_position.z > player.global_position.z + 12.0:
            n.queue_free()

func _check_pickups() -> void:
    for n in crystal_root.get_children():
        if n is Area3D and not n.get_meta("collected", false):
            if absf(n.global_position.z - player.global_position.z) < 1.15 and absf(n.global_position.x - player.global_position.x) < 1.0 and absf(n.global_position.y - player.global_position.y) < 1.8:
                n.set_meta("collected", true)
                var amount := 2 if power_timers["double"] > 0.0 else CRYSTAL_VALUE
                if power_timers["magnet"] > 0.0:
                    amount += 1
                crystals_run += amount
                n.queue_free()

func _check_collisions() -> void:
    for n in obstacle_root.get_children():
        if absf(n.global_position.z - player.global_position.z) < 0.95 and absf(n.global_position.x - player.global_position.x) < 0.9:
            if player.global_position.y > 1.55 or is_sliding:
                continue
            if power_timers["shield"] > 0.0:
                power_timers["shield"] = 0.0
                n.queue_free()
                _toast("SHIELD BLOCKED HIT!")
            else:
                _end_run()
                return

func _change_lane(amount: int) -> void:
    lane = clampi(lane + amount, 0, 2)
    target_x = LANES[lane]

func _jump() -> void:
    if player.is_on_floor() or player.global_position.y < 1.0:
        vertical_velocity = jump_strength
        is_sliding = false
        player.scale.y = 1.0

func _slide() -> void:
    if player.global_position.y < 1.1:
        is_sliding = true
        slide_timer = 0.75
        player.scale.y = 0.58

func _start_run() -> void:
    _clear_run_objects()
    player.position = Vector3(0, 0.9, 2.5)
    player.velocity = Vector3.ZERO
    player.scale = Vector3.ONE
    lane = 1
    target_x = 0.0
    vertical_velocity = 0.0
    run_speed = base_speed
    distance_m = 0.0
    crystals_run = 0
    elapsed = 0.0
    next_obstacle_z = 24.0
    next_crystal_z = 8.0
    power_timers = {"magnet": 0.0, "shield": 0.0, "double": 0.0, "boost": 0.0}
    var inventory: Dictionary = saved_data.get("inventory", {})
    for kind in ["magnet", "shield", "double"]:
        if int(inventory.get(kind, 0)) > 0:
            inventory[kind] = int(inventory[kind]) - 1
            power_timers[kind] = 12.0
    saved_data["inventory"] = inventory
    _save_game()
    running = true
    game_started = true
    _hide_all_panels()
    hud.visible = true
    _toast("RUN STARTED — SWIPE TO MOVE")

func _end_run() -> void:
    if not running:
        return
    running = false
    best_distance = maxf(best_distance, distance_m)
    crystals_total += crystals_run
    saved_data["crystals"] = crystals_total
    saved_data["best"] = best_distance
    _save_game()
    _show_gameover()

func _pause_run() -> void:
    if running:
        running = false
        pause_panel.visible = true

func _resume_run() -> void:
    pause_panel.visible = false
    running = true

func _clear_run_objects() -> void:
    for n in obstacle_root.get_children():
        n.queue_free()
    for n in crystal_root.get_children():
        n.queue_free()

func _build_ui() -> void:
    ui_layer = CanvasLayer.new()
    add_child(ui_layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_layer.add_child(root)

    hud = Control.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(hud)
    var top := HBoxContainer.new()
    top.position = Vector2(18, 16)
    top.size = Vector2(750, 58)
    hud.add_child(top)
    distance_label = _label("DISTANCE  0 m", 22)
    top.add_child(distance_label)
    crystal_label = _label("◆ 0", 22)
    top.add_child(crystal_label)
    var pause_btn := _button("Ⅱ", 54, 48)
    pause_btn.pressed.connect(_pause_run)
    top.add_child(pause_btn)

    var controls := HBoxContainer.new()
    controls.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    controls.offset_left = 20
    controls.offset_right = -20
    controls.offset_top = -92
    controls.offset_bottom = -14
    controls.alignment = BoxContainer.ALIGNMENT_CENTER
    controls.add_theme_constant_override("separation", 20)
    hud.add_child(controls)
    var left_btn := _button("◀", 68, 64)
    left_btn.pressed.connect(func(): _change_lane(-1))
    controls.add_child(left_btn)
    var jump_btn := _button("JUMP ▲", 132, 64)
    jump_btn.pressed.connect(_jump)
    controls.add_child(jump_btn)
    var slide_btn := _button("SLIDE ▼", 132, 64)
    slide_btn.pressed.connect(_slide)
    controls.add_child(slide_btn)
    var right_btn := _button("▶", 68, 64)
    right_btn.pressed.connect(func(): _change_lane(1))
    controls.add_child(right_btn)

    message_label = _label("", 18)
    message_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    message_label.position = Vector2(-260, 78)
    message_label.size = Vector2(520, 40)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud.add_child(message_label)

    menu_panel = _panel(root, Vector2(0, 0), Vector2(1280, 720))
    var menu_col := _center_column(menu_panel, 420)
    menu_col.add_child(_label("JUTTRUNNER", 48, true))
    menu_col.add_child(_label("DUNGEON RUNNER  •  RUN  •  FIGHT  •  EVOLVE", 16))
    menu_col.add_child(_spacer(12))
    var play := _button("▶  PLAY", 320, 54)
    play.pressed.connect(_start_run)
    menu_col.add_child(play)
    var hunters := _button("HUNTERS", 320, 48)
    hunters.pressed.connect(_show_hunters)
    menu_col.add_child(hunters)
    var shop := _button("SHOP  •  MANA CRYSTALS", 320, 48)
    shop.pressed.connect(_show_shop)
    menu_col.add_child(shop)
    menu_col.add_child(_label("Swipe: left/right • up: jump • down: slide", 15))
    best_label = _label("BEST RUN: 0 m    •    CRYSTALS: 0", 16)
    menu_col.add_child(best_label)

    gameover_panel = _panel(root, Vector2(0, 0), Vector2(1280, 720))
    var over_col := _center_column(gameover_panel, 420)
    over_col.add_child(_label("RUN ENDED", 42, true))
    over_col.add_child(_label("The dungeon claims another hunter.", 17))
    status_label = _label("", 22)
    over_col.add_child(status_label)
    var restart := _button("↻  RUN AGAIN", 320, 54)
    restart.pressed.connect(_start_run)
    over_col.add_child(restart)
    var home := _button("MAIN MENU", 320, 48)
    home.pressed.connect(_show_menu)
    over_col.add_child(home)

    pause_panel = _panel(root, Vector2(0, 0), Vector2(1280, 720))
    var pause_col := _center_column(pause_panel, 360)
    pause_col.add_child(_label("PAUSED", 42, true))
    var resume := _button("RESUME", 300, 52)
    resume.pressed.connect(_resume_run)
    pause_col.add_child(resume)
    var restart2 := _button("RESTART RUN", 300, 48)
    restart2.pressed.connect(_start_run)
    pause_col.add_child(restart2)
    var menu2 := _button("MAIN MENU", 300, 48)
    menu2.pressed.connect(_show_menu)
    pause_col.add_child(menu2)

    shop_panel = _panel(root, Vector2(0, 0), Vector2(1280, 720))
    var shop_col := _center_column(shop_panel, 540)
    shop_col.add_child(_label("MANA SHOP", 38, true))
    shop_col.add_child(_label("Spend collected crystals on temporary run power-ups.", 16))
    var magnet_btn := _button("MANA MAGNET  •  40 ◆  •  next run", 440, 48)
    magnet_btn.pressed.connect(func(): _buy_powerup("magnet", 40))
    shop_col.add_child(magnet_btn)
    var shield_btn := _button("SHIELD  •  50 ◆  •  next run", 440, 48)
    shield_btn.pressed.connect(func(): _buy_powerup("shield", 50))
    shop_col.add_child(shield_btn)
    var double_btn := _button("DOUBLE MANA  •  60 ◆  •  next run", 440, 48)
    double_btn.pressed.connect(func(): _buy_powerup("double", 60))
    shop_col.add_child(double_btn)
    var shop_balance := _label("", 18)
    shop_balance.name = "ShopBalance"
    shop_col.add_child(shop_balance)
    var back_shop := _button("BACK", 240, 44)
    back_shop.pressed.connect(_show_menu)
    shop_col.add_child(back_shop)

    hunters_panel = _panel(root, Vector2(0, 0), Vector2(1280, 720))
    var hunter_col := _center_column(hunters_panel, 540)
    hunter_col.add_child(_label("HUNTERS", 38, true))
    hunter_col.add_child(_label("Shadow Hunter — balanced and free", 20))
    hunter_col.add_child(_label("Blade Hunter — dash ability (coming in Stage 3)", 17))
    hunter_col.add_child(_label("Ice Hunter — freeze ability (coming in Stage 3)", 17))
    hunter_col.add_child(_label("Flame Hunter — protection (coming in Stage 3)", 17))
    hunter_col.add_child(_label("Original procedural placeholder hunter model", 14))
    var back_hunters := _button("BACK", 240, 44)
    back_hunters.pressed.connect(_show_menu)
    hunter_col.add_child(back_hunters)

    _hide_all_panels()
    hud.visible = false

func _label(text: String, font_size: int = 18, title_style: bool = false) -> Label:
    var label := Label.new()
    label.text = text
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", Color(0.78, 0.91, 1.0))
    if title_style:
        label.add_theme_color_override("font_color", Color(0.2, 0.78, 1.0))
    return label

func _button(text: String, width: float, height: float) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(width, height)
    b.add_theme_font_size_override("font_size", 18 if height > 48 else 16)
    b.add_theme_color_override("font_color", Color(0.88, 0.96, 1.0))
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.025, 0.07, 0.17, 0.94)
    normal.border_color = Color(0.0, 0.45, 1.0)
    normal.set_border_width_all(2)
    normal.set_corner_radius_all(10)
    normal.content_margin_left = 12
    normal.content_margin_right = 12
    b.add_theme_stylebox_override("normal", normal)
    var hover := normal.duplicate()
    hover.bg_color = Color(0.04, 0.16, 0.3, 0.98)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", hover)
    return b

func _panel(parent: Control, pos: Vector2, size: Vector2) -> PanelContainer:
    var p := PanelContainer.new()
    p.position = pos
    p.size = size
    p.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.008, 0.015, 0.055, 0.93)
    style.border_color = Color(0.0, 0.25, 0.75, 0.85)
    style.set_border_width_all(2)
    p.add_theme_stylebox_override("panel", style)
    parent.add_child(p)
    return p

func _center_column(panel: Control, width: float) -> VBoxContainer:
    var outer := CenterContainer.new()
    outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    panel.add_child(outer)
    var col := VBoxContainer.new()
    col.custom_minimum_size.x = width
    col.add_theme_constant_override("separation", 10)
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    outer.add_child(col)
    return col

func _spacer(height: float) -> Control:
    var s := Control.new()
    s.custom_minimum_size.y = height
    return s

func _hide_all_panels() -> void:
    menu_panel.visible = false
    gameover_panel.visible = false
    pause_panel.visible = false
    shop_panel.visible = false
    hunters_panel.visible = false

func _show_menu() -> void:
    running = false
    if ui_layer == null:
        return
    _hide_all_panels()
    menu_panel.visible = true
    hud.visible = false
    best_label.text = "BEST RUN: %d m    •    CRYSTALS: %d" % [int(best_distance), crystals_total]
    _update_shop_balance()

func _show_gameover() -> void:
    _hide_all_panels()
    gameover_panel.visible = true
    hud.visible = false
    status_label.text = "DISTANCE: %d m\nMANA CRYSTALS: +%d\nBEST: %d m" % [int(distance_m), crystals_run, int(best_distance)]

func _show_shop() -> void:
    _hide_all_panels()
    shop_panel.visible = true
    hud.visible = false
    _update_shop_balance()

func _show_hunters() -> void:
    _hide_all_panels()
    hunters_panel.visible = true
    hud.visible = false

func _update_shop_balance() -> void:
    if shop_panel == null:
        return
    var label := shop_panel.find_child("ShopBalance", true, false) as Label
    if label:
        label.text = "Available Mana Crystals: %d" % crystals_total

func _buy_powerup(kind: String, price: int) -> void:
    if crystals_total < price:
        _toast("NOT ENOUGH MANA CRYSTALS")
        return
    crystals_total -= price
    saved_data["crystals"] = crystals_total
    var inventory: Dictionary = saved_data.get("inventory", {})
    inventory[kind] = int(inventory.get(kind, 0)) + 1
    saved_data["inventory"] = inventory
    _save_game()
    _update_shop_balance()
    _toast("PURCHASED! EQUIPPED FOR NEXT RUN")

func _update_hud() -> void:
    distance_label.text = "DISTANCE  %d m" % int(distance_m)
    crystal_label.text = "◆ %d  (+%d)" % [crystals_total, crystals_run]
    if power_timers["magnet"] > 0:
        message_label.text = "MANA MAGNET  %.0fs" % power_timers["magnet"]
    elif power_timers["shield"] > 0:
        message_label.text = "SHIELD  %.0fs" % power_timers["shield"]
    elif power_timers["double"] > 0:
        message_label.text = "DOUBLE MANA  %.0fs" % power_timers["double"]
    elif power_timers["boost"] > 0:
        message_label.text = "SPEED BURST  %.0fs" % power_timers["boost"]
    else:
        message_label.text = ""

func _toast(message: String) -> void:
    if message_label:
        message_label.text = message

func _load_save() -> void:
    if FileAccess.file_exists(SAVE_PATH):
        var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
        if file:
            var parsed = JSON.parse_string(file.get_as_text())
            if parsed is Dictionary:
                saved_data = parsed
    crystals_total = int(saved_data.get("crystals", 0))
    best_distance = float(saved_data.get("best", 0.0))

func _save_game() -> void:
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(saved_data, "\t"))

